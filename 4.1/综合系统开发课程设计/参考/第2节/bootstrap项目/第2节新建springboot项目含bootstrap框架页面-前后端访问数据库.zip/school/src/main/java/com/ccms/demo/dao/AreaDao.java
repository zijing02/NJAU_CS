package com.ccms.demo.dao;

import com.ccms.demo.dao.provider.AreaDynaSqlProvider;
import com.ccms.demo.pojo.SysArea;
import org.apache.ibatis.annotations.SelectProvider;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;


@Repository
public interface AreaDao {
	@SelectProvider(type = AreaDynaSqlProvider.class, method = "selectWithParam")
	public List<SysArea> selectAreaList(Map<String, Object> params);
}
