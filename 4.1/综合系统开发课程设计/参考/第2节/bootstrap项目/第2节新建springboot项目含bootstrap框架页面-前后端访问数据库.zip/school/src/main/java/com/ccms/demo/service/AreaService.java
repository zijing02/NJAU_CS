package com.ccms.demo.service;


import com.ccms.demo.pojo.SysArea;

import java.util.List;


public interface AreaService {
	/**
	 * 获取所有列表
	 * @param areaType  区域等级
	 */
	public List<SysArea> getAreaList(SysArea area);
}
