package com.ccms.demo;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
@MapperScan("com.ccms.demo.dao")
public class CcmsDemoApplication {

    public static void main(String[] args) {
        SpringApplication.run(CcmsDemoApplication.class, args);
    }

}
