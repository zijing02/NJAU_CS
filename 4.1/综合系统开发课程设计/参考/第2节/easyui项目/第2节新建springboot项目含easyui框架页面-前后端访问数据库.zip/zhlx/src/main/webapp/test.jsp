<%--
  Created by IntelliJ IDEA.
  User: xwsky
  Date: 2022/6/2
  Time: 14:25
  To change this template use File | Settings | File Templates.
--%>
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<html>
<head>
    <title>index</title>
</head>
<body>
<h2>Hello , JSP</h2>
</body>
</html>
