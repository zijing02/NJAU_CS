package com.ecpbm.demo.service;

import com.ecpbm.demo.pojo.Video;

import java.util.List;

public interface VideoService {
    List<Video> listVideo();
}
