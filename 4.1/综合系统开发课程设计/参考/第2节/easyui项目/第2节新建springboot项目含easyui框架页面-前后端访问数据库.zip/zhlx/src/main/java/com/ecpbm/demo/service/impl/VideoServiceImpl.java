package com.ecpbm.demo.service.impl;

import com.ecpbm.demo.dao.VideoDao;
import com.ecpbm.demo.pojo.Video;
import com.ecpbm.demo.service.VideoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class VideoServiceImpl implements VideoService {

    @Autowired
    private VideoDao videoDao;

    @Override
    public List<Video> listVideo() {

        return videoDao.listVideo();
    }
}
