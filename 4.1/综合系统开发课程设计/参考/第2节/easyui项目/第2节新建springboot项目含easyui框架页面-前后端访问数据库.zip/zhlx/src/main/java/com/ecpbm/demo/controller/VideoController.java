package com.ecpbm.demo.controller;

import com.ecpbm.demo.pojo.Video;
import com.ecpbm.demo.service.VideoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/video")
public class VideoController {

    @Autowired
    private VideoService videoService;

    @GetMapping("list")
    public Object listVideo(){

        List<Video> list=videoService.listVideo();
        //return JsonData.builderSccess(1,list);
        return list;
    }

}
