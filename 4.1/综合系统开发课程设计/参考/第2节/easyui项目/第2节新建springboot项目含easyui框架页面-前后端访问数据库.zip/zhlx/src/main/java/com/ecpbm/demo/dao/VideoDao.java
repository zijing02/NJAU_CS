package com.ecpbm.demo.dao;

import com.ecpbm.demo.pojo.Video;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Repository
public class VideoDao {
    /**
     * https://blog.csdn.net/weixin_43730508/article/details/108044904
     * Map是个接口
     *    HashMap是它的实现类。 这就是new 了一个对象
     */
    private static Map<Integer, Video> videoMap=new HashMap<>();

    static{
        videoMap.put(1,new Video(1,"hello"));
        videoMap.put(2,new Video(2,"world"));
    }

    public List<Video> listVideo(){
        List<Video> list=new ArrayList<>();
        list.addAll(videoMap.values());
        return list;
    }
}

