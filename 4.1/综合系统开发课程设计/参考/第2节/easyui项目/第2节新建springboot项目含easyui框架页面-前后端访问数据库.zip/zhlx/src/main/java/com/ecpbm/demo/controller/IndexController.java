package com.ecpbm.demo.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author lanwu
 * @Title
 * @date 2022/06/02 12:44
 **/
@RestController
public class IndexController {
    @RequestMapping(value = "/index")
    public String index(){
        return "admin_login";
    }
}