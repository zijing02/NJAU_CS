package com.ecpbm.demo.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller

public class TestjspController {

        /**
         * 页面跳转
         */
        @RequestMapping(value = "/productlist",method = RequestMethod.GET)
        public String productlist() {
            //productlist打开网页，然后调用list(..)返回数据
            return "productlist";

        }

}
