package com.ecpbm.demo.dao;

import com.ecpbm.demo.pojo.Functions;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface FunctionDao {
	// 根据管理员id,获取功能权限
	@Select("select * from functions where id in (select fid from powers where aid = #{aid} )")
	List<Functions> selectByAdminId(Integer aid);
}
